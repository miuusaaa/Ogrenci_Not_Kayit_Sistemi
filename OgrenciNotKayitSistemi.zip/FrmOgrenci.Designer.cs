﻿namespace Öğrenci_Not_Kayıt_Sistemi
{
    partial class FrmOgrenci
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            label14 = new Label();
            pbFotograf = new PictureBox();
            lblNo = new Label();
            lblSoyad = new Label();
            lblAd = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            label5 = new Label();
            label4 = new Label();
            label11 = new Label();
            lblS3 = new Label();
            lblS2 = new Label();
            lblS1 = new Label();
            groupBox2 = new GroupBox();
            lblOrtalama = new Label();
            label12 = new Label();
            lblSonuc = new Label();
            label6 = new Label();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pbFotograf).BeginInit();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(label14);
            groupBox1.Controls.Add(pbFotograf);
            groupBox1.Controls.Add(lblNo);
            groupBox1.Controls.Add(lblSoyad);
            groupBox1.Controls.Add(lblAd);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Location = new Point(12, 46);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(384, 290);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Öğrenci Bilgileri";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(67, 202);
            label14.Name = "label14";
            label14.Size = new Size(52, 15);
            label14.TabIndex = 13;
            label14.Text = "Fotograf";
            // 
            // pbFotograf
            // 
            pbFotograf.Location = new Point(41, 84);
            pbFotograf.Name = "pbFotograf";
            pbFotograf.Size = new Size(100, 98);
            pbFotograf.TabIndex = 11;
            pbFotograf.TabStop = false;
            // 
            // lblNo
            // 
            lblNo.AutoSize = true;
            lblNo.Location = new Point(305, 163);
            lblNo.Name = "lblNo";
            lblNo.Size = new Size(44, 15);
            lblNo.TabIndex = 10;
            lblNo.Text = "label14";
            // 
            // lblSoyad
            // 
            lblSoyad.AutoSize = true;
            lblSoyad.Location = new Point(305, 119);
            lblSoyad.Name = "lblSoyad";
            lblSoyad.Size = new Size(44, 15);
            lblSoyad.TabIndex = 9;
            lblSoyad.Text = "label14";
            // 
            // lblAd
            // 
            lblAd.AutoSize = true;
            lblAd.Location = new Point(311, 81);
            lblAd.Name = "lblAd";
            lblAd.Size = new Size(38, 15);
            lblAd.TabIndex = 5;
            lblAd.Text = "label6";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(190, 163);
            label3.Name = "label3";
            label3.Size = new Size(64, 15);
            label3.TabIndex = 2;
            label3.Text = "Numarası :";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(190, 119);
            label2.Name = "label2";
            label2.Size = new Size(48, 15);
            label2.TabIndex = 1;
            label2.Text = "Soyadı :";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(190, 81);
            label1.Name = "label1";
            label1.Size = new Size(31, 15);
            label1.TabIndex = 0;
            label1.Text = "Adı :";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(52, 98);
            label5.Name = "label5";
            label5.Size = new Size(50, 15);
            label5.TabIndex = 4;
            label5.Text = "Sınav 2 :";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(52, 50);
            label4.Name = "label4";
            label4.Size = new Size(50, 15);
            label4.TabIndex = 3;
            label4.Text = "Sınav 1 :";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(52, 156);
            label11.Name = "label11";
            label11.Size = new Size(50, 15);
            label11.TabIndex = 5;
            label11.Text = "Sınav 3 :";
            // 
            // lblS3
            // 
            lblS3.AutoSize = true;
            lblS3.Location = new Point(160, 156);
            lblS3.Name = "lblS3";
            lblS3.Size = new Size(44, 15);
            lblS3.TabIndex = 6;
            lblS3.Text = "label12";
            // 
            // lblS2
            // 
            lblS2.AutoSize = true;
            lblS2.Location = new Point(160, 98);
            lblS2.Name = "lblS2";
            lblS2.Size = new Size(44, 15);
            lblS2.TabIndex = 7;
            lblS2.Text = "label13";
            // 
            // lblS1
            // 
            lblS1.AutoSize = true;
            lblS1.Location = new Point(160, 50);
            lblS1.Name = "lblS1";
            lblS1.Size = new Size(0, 15);
            lblS1.TabIndex = 8;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(lblOrtalama);
            groupBox2.Controls.Add(label12);
            groupBox2.Controls.Add(lblSonuc);
            groupBox2.Controls.Add(label6);
            groupBox2.Controls.Add(lblS1);
            groupBox2.Controls.Add(label4);
            groupBox2.Controls.Add(lblS2);
            groupBox2.Controls.Add(label5);
            groupBox2.Controls.Add(lblS3);
            groupBox2.Controls.Add(label11);
            groupBox2.Location = new Point(475, 57);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(290, 279);
            groupBox2.TabIndex = 9;
            groupBox2.TabStop = false;
            groupBox2.Text = "Not Bilgileri";
            // 
            // lblOrtalama
            // 
            lblOrtalama.AutoSize = true;
            lblOrtalama.Location = new Point(160, 200);
            lblOrtalama.Name = "lblOrtalama";
            lblOrtalama.Size = new Size(44, 15);
            lblOrtalama.TabIndex = 12;
            lblOrtalama.Text = "label12";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(52, 200);
            label12.Name = "label12";
            label12.Size = new Size(62, 15);
            label12.TabIndex = 11;
            label12.Text = "Ortalama :";
            // 
            // lblSonuc
            // 
            lblSonuc.AutoSize = true;
            lblSonuc.Location = new Point(160, 242);
            lblSonuc.Name = "lblSonuc";
            lblSonuc.Size = new Size(44, 15);
            lblSonuc.TabIndex = 10;
            lblSonuc.Text = "label12";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(56, 242);
            label6.Name = "label6";
            label6.Size = new Size(46, 15);
            label6.TabIndex = 9;
            label6.Text = "Sonuç :";
            // 
            // FrmOgrenci
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Name = "FrmOgrenci";
            Load += FrmOgrenci_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pbFotograf).EndInit();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private Label label10;
        private Label label9;
        private Label label8;
        private Label lblNo;
        private Label lblAd;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private Label label11;
        private Label lblS3;
        private Label lblS2;
        private Label lblS1;
        private GroupBox groupBox2;
        private Label lblSoyad;
        private Label label14;
        private PictureBox pbFotograf;
        private Label lblOrtalama;
        private Label label12;
        private Label lblSonuc;
        private Label label6;
    }
}